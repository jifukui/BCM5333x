/*
 * $Id: subport.h,v 1.22 Broadcom SDK $
 * $Copyright: Copyright 2015 Broadcom Corporation.
 * This program is the proprietary software of Broadcom Corporation
 * and/or its licensors, and may only be used, duplicated, modified
 * or distributed pursuant to the terms and conditions of a separate,
 * written license agreement executed between you and Broadcom
 * (an "Authorized License").  Except as set forth in an Authorized
 * License, Broadcom grants no license (express or implied), right
 * to use, or waiver of any kind with respect to the Software, and
 * Broadcom expressly reserves all rights in and to the Software
 * and all intellectual property rights therein.  IF YOU HAVE
 * NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS SOFTWARE
 * IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE
 * ALL USE OF THE SOFTWARE.  
 *  
 * Except as expressly set forth in the Authorized License,
 *  
 * 1.     This program, including its structure, sequence and organization,
 * constitutes the valuable trade secrets of Broadcom, and you shall use
 * all reasonable efforts to protect the confidentiality thereof,
 * and to use this information only in connection with your use of
 * Broadcom integrated circuit products.
 *  
 * 2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS
 * PROVIDED "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES,
 * REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY,
 * OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
 * DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
 * NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES,
 * ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR
 * CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING
 * OUT OF USE OR PERFORMANCE OF THE SOFTWARE.
 * 
 * 3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL
 * BROADCOM OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL,
 * INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES WHATSOEVER
 * ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY
 * TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF
 * THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF OR USD 1.00,
 * WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING
 * ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.$
 *
 * This file contains subport definitions internal to the BCM library.
 */

#include <sal/core/sync.h>
#include <bcm/subport.h>

#ifndef _BCM_INT_ESW_SUBPORT_H_
#define _BCM_INT_ESW_SUBPORT_H_

/** Raghu Start change */

/*****************************************
* Subport CoE common section - start
******************************************/

/* The common data structures between KT2 and TD2+ Subport-CoE 
   implementation */

/* SUBPORT GPORT CoE subtype shift & mask definitions */

/* Subport CoE Common defines */

#define _BCM_COE_PORT_TYPE_ETHERNET         0
#define _BCM_COE_PORT_TYPE_CASCADED         4
#define _BCM_COE_PORT_TYPE_CASCADED_LINKPHY 0
#define _BCM_COE_PORT_TYPE_CASCADED_SUBTAG  1

/* Subport type defs */
#define _BCM_SUBPORT_COE_TYPE_ETHERNET      0
#define _BCM_SUBPORT_COE_TYPE_CASCADED      1
#define _BCM_SUBPORT_COE_TYPE_LINKPHY       2
#define _BCM_SUBPORT_COE_TYPE_SUBTAG        3

/*
* LinkPHY/SubTag Subport group gport format 
* bit 31-26 -- gport type (subport group)
* bit 25-24 -- subport group type (cascaded)
* bit 18-17 -- subport subtype (linkphy / subtag )
* bit 17    -- subport group is trunk indicator
* bit 16-9  -- subport group port number/trunk group id
* bit 8-0   -- subport group index
*/
#define _BCM_SUBPORT_COE_GROUP_TYPE_MASK      0x3
#define _BCM_SUBPORT_COE_GROUP_TYPE_SHIFT     24
#define _BCM_SUBPORT_COE_GROUP_SUBTYPE_MASK   0x3
#define _BCM_SUBPORT_COE_GROUP_SUBTYPE_SHIFT  18
#define _BCM_SUBPORT_COE_GROUP_PORT_MASK      0xFF
#define _BCM_SUBPORT_COE_GROUP_PORT_SHIFT     9
#define _BCM_SUBPORT_COE_GROUP_SPGID_MASK     0x1FF
#define _BCM_SUBPORT_COE_GROUP_SPGID_SHIFT    0

/*
* LinkPHY/SubTag Subport port gport format 
* bit 31-26  -- gport type (subport port)
* bit 25-24  -- subport port type (LinkPHY / SubTag)
* bit 23-15  -- zero
* bit 14-07  -- subport module index(range 0 to 255) 
* bit 06-00  -- subport port index  (range 0 to 127) 
*/

#define _BCM_SUBPORT_COE_PORT_TYPE_MASK         0x3
#define _BCM_SUBPORT_COE_PORT_TYPE_SHIFT        24
#define _BCM_SUBPORT_COE_PORT_ZERO_BITS_MASK    0x1FF
#define _BCM_SUBPORT_COE_PORT_ZERO_BITS_SHIFT   15
#define _BCM_SUBPORT_COE_PORT_MODULE_MASK       0xFF
#define _BCM_SUBPORT_COE_PORT_MODULE_SHIFT      7
#define _BCM_SUBPORT_COE_PORT_PORT_MASK         0x7F
#define _BCM_SUBPORT_COE_PORT_PORT_SHIFT        0

#define _BCM_SUBPORT_COE_PORT_VALUE_MASK        0x7FFF

#define BCM_SUBPORT_COE_DEFAULT_ETHERTYPE       0x8874

/* Check if gport is LinkPHY subport_group */
#define _BCM_COE_GPORT_IS_LINKPHY_SUBPORT_GROUP(_subport_group)    \
        ((((_subport_group >> _BCM_SUBPORT_COE_GROUP_SUBTYPE_SHIFT) & \
            _BCM_SUBPORT_COE_GROUP_SUBTYPE_MASK) ==    \
            _BCM_SUBPORT_COE_TYPE_LINKPHY) && \
         (((_subport_group >> _BCM_SUBPORT_COE_GROUP_TYPE_SHIFT) & \
            _BCM_SUBPORT_COE_GROUP_TYPE_MASK) ==    \
            _BCM_SUBPORT_COE_TYPE_CASCADED))


/* Check if gport is SubTag subport_group */
#define _BCM_COE_GPORT_IS_SUBTAG_SUBPORT_GROUP(_subport_group)    \
        ((((_subport_group >> _BCM_SUBPORT_COE_GROUP_SUBTYPE_SHIFT) & \
            _BCM_SUBPORT_COE_GROUP_SUBTYPE_MASK) ==    \
            _BCM_SUBPORT_COE_TYPE_SUBTAG) && \
         (((_subport_group >> _BCM_SUBPORT_COE_GROUP_TYPE_SHIFT) & \
            _BCM_SUBPORT_COE_GROUP_TYPE_MASK) ==    \
            _BCM_SUBPORT_COE_TYPE_CASCADED))

/* Set the subport port gport  type */
#define _BCM_SUBPORT_COE_PORT_TYPE_SET(_subport_port, _type)  \
    (_subport_port |= ((_type & _BCM_SUBPORT_COE_PORT_TYPE_MASK) \
          << _BCM_SUBPORT_COE_PORT_TYPE_SHIFT))


/* Get port number/trunk id associated with subport_group gport */
#define _BCM_SUBPORT_COE_GROUP_PORT_GET(_subport_group) \
        ((_subport_group >> _BCM_SUBPORT_COE_GROUP_PORT_SHIFT) & \
            _BCM_SUBPORT_COE_GROUP_PORT_MASK)

/* Get group id associated with subport_group gport */
#define _BCM_SUBPORT_COE_GROUP_ID_GET(_subport_group) \
        (((_subport_group) >> _BCM_SUBPORT_COE_GROUP_SPGID_SHIFT) & \
            _BCM_SUBPORT_COE_GROUP_SPGID_MASK)

#define _BCM_SUBPORT_COE_GROUP_TYPE_CASCADED_SET(_subport_group) \
    ((_subport_group) |= ((_BCM_SUBPORT_COE_TYPE_CASCADED & \
                          _BCM_SUBPORT_COE_GROUP_TYPE_MASK) \
                              << _BCM_SUBPORT_COE_GROUP_TYPE_SHIFT))
 
/*
 * Subtended port Function Vector Driver
 */
typedef struct bcm_esw_subport_drv_s {
    /*
     * Subport APIs
     */

    /* Initial subport module handlers */

    /* Initalize enhanced subport module */
    int (*subport_init)(int unit);
    /* Create Subport group */
    int (*subport_group_create)(int unit, bcm_subport_group_config_t *config,
             bcm_gport_t *group);
    /* Delete Subport group */
    int (*subport_group_get)(int unit, bcm_gport_t group,
             bcm_subport_group_config_t *config);
    /* Traverse Subport group */
    int (*subport_group_traverse)(int unit, bcm_gport_t subport_group,
                          bcm_subport_port_traverse_cb cb, void *user_data);
    /* Destroy Subport group */
    int (*subport_group_destroy)(int unit, bcm_gport_t group);
    /* Set LinkPhy config */
    int (*subport_linkphy_config_set)(int unit, bcm_gport_t port,
           bcm_subport_group_linkphy_config_t *linkphy_config);
    /* Get LinkPhy config */
    int (*subport_linkphy_config_get)(int unit, bcm_gport_t port,
           bcm_subport_group_linkphy_config_t *linkphy_config);   

    /* Subport port add */
    int (*subport_port_add)(int unit, bcm_subport_config_t *config, 
                            bcm_gport_t *port); 
    /* Subport port get */
    int (*subport_port_get)(int unit, bcm_gport_t port, 
                            bcm_subport_config_t *config);
    /* Subport port traverse */
    int (*subport_port_traverse)(int unit, 
                                 bcm_subport_port_traverse_cb cb, 
                                 void *user_data);
    /* Subport port stat set */
    int (*subport_port_stat_set)(int unit, bcm_gport_t port, 
                                 int stream_id,
                                 bcm_subport_stat_t stat_type, uint64 val);
    /* Subport port stat get */
    int (*subport_port_stat_get)(int unit, bcm_gport_t port, int stream_id,
                                 bcm_subport_stat_t stat_type, uint64 *val);
    /* Subport port delete */
    int (*subport_port_delete)(int unit, bcm_gport_t port);
    /* Subport module cleanup */
    int (*subport_cleanup)(int unit);

    /* CoE module handlers */

    /* Init CoE subport module handlers */
    int (*coe_init)(int unit);
    /* Create Subport group */
    int (*coe_group_create)(int unit, bcm_subport_group_config_t *config,
			 bcm_gport_t *group);
    /* Delete Subport group */
    int (*coe_group_get)(int unit, bcm_gport_t group,
             bcm_subport_group_config_t *config);
    /* Traverse Subport group */
    int (*coe_group_traverse)(int unit, bcm_gport_t subport_group,
                              bcm_subport_port_traverse_cb cb, 
                              void *user_data);
    /* Destroy Subport group */
    int (*coe_group_destroy)(int unit, bcm_gport_t group);
    /* Set LinkPhy config */
    int (*coe_group_linkphy_config_set)(int unit, bcm_gport_t port,
          bcm_subport_group_linkphy_config_t *linkphy_config);
    /* Get LinkPhy config */
    int (*coe_group_linkphy_config_get)(int unit, bcm_gport_t port,
         bcm_subport_group_linkphy_config_t *linkphy_config); 

    /* Subport port add */
    int (*coe_port_add)(int unit, bcm_subport_config_t *config, 
                        bcm_gport_t *port);
    /* Subport port get */
    int (*coe_port_get)(int unit, bcm_gport_t port, 
                        bcm_subport_config_t *config);
    /* Subport port traverse */
    int (*coe_port_traverse)(int unit, bcm_subport_port_traverse_cb cb, 
                             void *user_data);
    /* Subport port stat set */
    int (*coe_port_stat_set)(int unit, bcm_gport_t port, int stream_id,
                         bcm_subport_stat_t stat_type, uint64 val);
    /* Subport port stat get */
    int (*coe_port_stat_get)(int unit, bcm_gport_t port, int stream_id,
                         bcm_subport_stat_t stat_type, uint64 *val);
    /* Subport port delete */
    int (*coe_port_delete)(int unit, bcm_gport_t port);
    /* Subport module cleanup */
    int (*coe_cleanup)(int unit);

} bcm_esw_subport_drv_t;

extern bcm_esw_subport_drv_t      *bcm_esw_subport_drv[BCM_MAX_NUM_UNITS];

#define BCM_ESW_SUBPORT_DRV(_u)   (bcm_esw_subport_drv[(_u)])

extern int bcmi_subport_common_init(int unit, bcm_esw_subport_drv_t *drv);

/*
 * Bitmap of subport group id
 * Each Subport group created has unique group id
 * across all ports in the device irrespective of
 * group type LinkPHY/SubTag
 */
extern SHR_BITDCL *_bcm_subport_group_bitmap[BCM_MAX_NUM_UNITS];

/* Count of all subport groups created */
extern int _bcm_subport_group_count[BCM_MAX_NUM_UNITS];

/* Count subport port per subport group*/
extern int *(_bcm_subport_group_subport_port_count[BCM_MAX_NUM_UNITS]);


/*********************************
* Subport common  section - end
**********************************/



/*********************************
* SubTag subport section - start
**********************************/

/* Bitmap of SubTag subport group id */
extern SHR_BITDCL *_bcm_subtag_group_bitmap[BCM_MAX_NUM_UNITS];

/* Count of all SubTag subport groups created */
extern int _bcm_subtag_subport_group_count[BCM_MAX_NUM_UNITS];

extern SHR_BITDCL *_bcm_subtag_vlan_id_bitmap
                   [BCM_MAX_NUM_UNITS][SOC_MAX_NUM_PORTS];

/* SubTag subport port info structure */
typedef struct {
    /* Subport group gort attached to */
    bcm_gport_t  group;
    /* VLAN ID */
    bcm_vlan_t   vlan;
    int          valid;
    int          subtag_tcam_hw_idx;
    int          modport_subport_idx;
    /* Subport-Port, represented as GPORT_SUBPORT */
    bcm_gport_t  subport_port;
    /* Associated subport, represented as GPORT_MODPORT */
    bcm_gport_t  subport_modport;
    int          phb_valid;
    int          priority;
    int          color;
    int          nh_index;
} _bcm_subtag_subport_port_info_t;

extern _bcm_subtag_subport_port_info_t
           *(_bcm_subtag_subport_port_info[BCM_MAX_NUM_UNITS]);


/*********************************
* SubTag subport section - end
**********************************/


/****  Misc section start */

extern sal_mutex_t _bcm_subport_mutex[BCM_MAX_NUM_UNITS];

#define _BCM_SUBPORT_COE_LOCK(unit) \
    sal_mutex_take(_bcm_subport_mutex[unit], sal_mutex_FOREVER);

#define _BCM_SUBPORT_COE_UNLOCK(unit) \
    sal_mutex_give(_bcm_subport_mutex[unit]);


#define _BCM_SUBPORT_COE_CHECK_INIT(_unit_) \
        if (!_bcm_subport_group_bitmap[_unit_]) \
            return BCM_E_INIT

/****  Misc section end */


/** Common defines for CoE implementation - start */

/*
 * Subport group usage bitmap operations
 */
#define _BCM_SUBPORT_COE_GROUP_USED_GET(_u_, _group_) \
                SHR_BITGET(_bcm_subport_group_bitmap[_u_], (_group_))

#define _BCM_SUBPORT_COE_GROUP_USED_SET(_u_, _group_) \
                SHR_BITSET(_bcm_subport_group_bitmap[_u_], (_group_))

#define _BCM_SUBPORT_COE_GROUP_USED_CLR(_u_, _group_) \
                SHR_BITCLR(_bcm_subport_group_bitmap[_u_], (_group_))

/*
 * SubTag subport group usage bitmap operations
 */
#define _BCM_SUBPORT_COE_SUBTAG_GROUP_USED_GET(_u_, _group_) \
            SHR_BITGET(_bcm_subtag_group_bitmap[_u_], (_group_))

#define _BCM_SUBPORT_COE_SUBTAG_GROUP_USED_SET(_u_, _group_) \
            SHR_BITSET(_bcm_subtag_group_bitmap[_u_], (_group_))

#define _BCM_SUBPORT_COE_SUBTAG_GROUP_USED_CLR(_u_, _group_) \
            SHR_BITCLR(_bcm_subtag_group_bitmap[_u_], (_group_))

/* Katana2 SubTag VLAN id usage bitmap for given port*/
#define _BCM_COE_SUBTAG_VLAN_ID_USED_GET(_u_, _p, _vlan_id_) \
            SHR_BITGET(_bcm_subtag_vlan_id_bitmap[_u_][_p], (_vlan_id_))

#define _BCM_COE_SUBTAG_VLAN_ID_USED_SET(_u_, _p, _vlan_id_) \
            SHR_BITSET(_bcm_subtag_vlan_id_bitmap[_u_][_p], (_vlan_id_))

#define _BCM_COE_SUBTAG_VLAN_ID_USED_CLR(_u_, _p, _vlan_id_) \
            SHR_BITCLR(_bcm_subtag_vlan_id_bitmap[_u_][_p], (_vlan_id_))


/* Set the SubTag subport group gport */

/* The encoding is like this, based on the flags used:
    GPORT-TYPE-SUBPORT, SUBTYPE-SUBPORT, PHYSICAL-PORT, GroupId
 */

#define _BCM_SUBPORT_COE_SUBTAG_GROUP_SET(_subport_group, \
                                          _port, _gid) \
            (BCM_GPORT_SUBPORT_GROUP_SET((_subport_group), \
                        (((_BCM_SUBPORT_COE_TYPE_SUBTAG & \
                          _BCM_SUBPORT_COE_GROUP_SUBTYPE_MASK) \
                              << _BCM_SUBPORT_COE_GROUP_SUBTYPE_SHIFT) | \
                         ((_port & _BCM_SUBPORT_COE_GROUP_PORT_MASK) \
                              << _BCM_SUBPORT_COE_GROUP_PORT_SHIFT) | \
                         ((_gid & _BCM_SUBPORT_COE_GROUP_SPGID_MASK) \
                              << _BCM_SUBPORT_COE_GROUP_SPGID_SHIFT))))

/* Set the LinkPHY subport group gport */

/* The encoding is like this, based on the flags used:
    GPORT-TYPE-SUBPORT, SUBTYPE-LINKPHY, PHYSICAL-PORT, GroupId
 */
#define _BCM_COE_LINKPHY_SUBPORT_GROUP_SET(_subport_group, \
                                           _port, _gid) \
    (BCM_GPORT_SUBPORT_GROUP_SET((_subport_group), \
                        (((_BCM_SUBPORT_COE_TYPE_LINKPHY & \
                          _BCM_SUBPORT_COE_GROUP_SUBTYPE_MASK) \
                              << _BCM_SUBPORT_COE_GROUP_SUBTYPE_SHIFT) | \
                         ((_port & _BCM_SUBPORT_COE_GROUP_PORT_MASK) \
                              << _BCM_SUBPORT_COE_GROUP_PORT_SHIFT) | \
                         ((_gid & _BCM_SUBPORT_COE_GROUP_SPGID_MASK) \
                              << _BCM_SUBPORT_COE_GROUP_SPGID_SHIFT))))

/** Common defines for CoE implementation - end */

#ifdef BCM_TRIDENT2PLUS_SUPPORT

#define _BCM_TD2P_SUBPORT_COE_GROUP_MAX     (512)
#define _BCM_TD2P_SUBPORT_COE_PORT_MAX      (512)
#define _BCM_TD2P_MAX_SUBPORT_COE_PER_PORT  (80)
#define _BCM_TD2P_MAX_SUBPORT_COE_PER_MOD   (128)


#define _BCM_SUBPORT_COE_SUBTAG_PORT_INFO_VALID_GET(unit, tcam_hw_id) \
    (_bcm_subtag_subport_port_info[unit][tcam_hw_id].valid)

#define _BCM_SUBPORT_COE_SUBTAG_PORT_INFO_GROUP_GET(unit, tcam_hw_id) \
    (_bcm_subtag_subport_port_info[unit][tcam_hw_id].group)

#define _BCM_SUBPORT_COE_SUBTAG_PORT_INFO_VLAN_GET(unit, tcam_hw_id) \
    (_bcm_subtag_subport_port_info[unit][tcam_hw_id].vlan)

#define _BCM_SUBPORT_COE_SUBTAG_PORT_INFO_TCAM_HW_ID_GET(unit, tcam_hw_id) \
    (_bcm_subtag_subport_port_info[unit][tcam_hw_id].subtag_tcam_hw_idx)

#define _BCM_SUBPORT_COE_SUBTAG_PORT_INFO_SUBPORT_MODPORT_GET(unit, tcam_hw_id) \
    (_bcm_subtag_subport_port_info[unit][tcam_hw_id].subport_modport)

#define _BCM_SUBPORT_COE_SUBTAG_PORT_INFO_MODPORT_IDX_GET(unit, tcam_hw_id) \
    (_bcm_subtag_subport_port_info[unit][tcam_hw_id].modport_subport_idx)

#define _BCM_SUBPORT_COE_SUBTAG_PORT_INFO_SET(unit, tcam_hw_id, \
        sp_group, vlan_id, subport_port_val, subport_modport_val, phbValid, \
        pri, col, is_valid, modport_subport_idx_val) \
{ \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].group = sp_group; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].vlan = vlan_id; \
    _bcm_subtag_subport_port_info[unit] \
                                 [tcam_hw_id].subtag_tcam_hw_idx = \
                                 tcam_hw_id; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].subport_port = \
                                subport_port_val; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].subport_modport = \
                                subport_modport_val; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].phb_valid = phbValid; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].priority = pri; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].color = col; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].valid = is_valid; \
    _bcm_subtag_subport_port_info[unit][tcam_hw_id].modport_subport_idx = \
                                modport_subport_idx_val; \
}

/* Set the subport port gport mod,port id */
#define _BCM_SUBPORT_COE_PORT_ID_SET(_subport_port, mod, port)  \
    (BCM_GPORT_SUBPORT_PORT_SET((_subport_port), \
        ((mod & _BCM_SUBPORT_COE_PORT_MODULE_MASK) \
             << _BCM_SUBPORT_COE_PORT_MODULE_SHIFT) | \
        ((port & _BCM_SUBPORT_COE_PORT_PORT_MASK) \
             << _BCM_SUBPORT_COE_PORT_PORT_SHIFT)))

/* Get the subport port gport mod id */
#define _BCM_SUBPORT_COE_PORT_ID_MOD_GET(_subport_port)  \
        ((_subport_port >> _BCM_SUBPORT_COE_PORT_MODULE_SHIFT) & \
                 _BCM_SUBPORT_COE_PORT_MODULE_MASK)

/* Get the subport port gport port id */
#define _BCM_SUBPORT_COE_PORT_ID_PORT_GET(_subport_port)  \
        ((_subport_port >> _BCM_SUBPORT_COE_PORT_PORT_SHIFT) & \
                 _BCM_SUBPORT_COE_PORT_PORT_MASK)   

/* Get the subport port gport mod id */
#define _BCM_SUBPORT_COE_PORT_ID_GET(_subport_port)  \
        ((_subport_port & (_BCM_SUBPORT_COE_PORT_VALUE_MASK)))

/* Check if gport is SubTag subport_port */
#define _BCM_COE_GPORT_IS_SUBTAG_SUBPORT_PORT(_unit, _subport_port)    \
        (((((_subport_port) >> _BCM_SUBPORT_COE_PORT_TYPE_SHIFT) & \
                        _BCM_SUBPORT_COE_PORT_TYPE_MASK) == \
                        _BCM_SUBPORT_COE_TYPE_SUBTAG) && \
         ((((_subport_port) >> _BCM_SUBPORT_COE_PORT_ZERO_BITS_SHIFT) & \
                        _BCM_SUBPORT_COE_PORT_ZERO_BITS_MASK) == 0))


#endif /* BCM_TRIDENT2PLUS_SUPPORT */


/** Raghu End change */

#ifdef BCM_KATANA2_SUPPORT

/* Subport Common defines */
#define _BCM_KT2_PORT_TYPE_ETHERNET         _BCM_COE_PORT_TYPE_ETHERNET
#define _BCM_KT2_PORT_TYPE_CASCADED         _BCM_COE_PORT_TYPE_CASCADED
#define _BCM_KT2_PORT_TYPE_CASCADED_LINKPHY _BCM_COE_PORT_TYPE_CASCADED_LINKPHY
#define _BCM_KT2_PORT_TYPE_CASCADED_SUBTAG  _BCM_COE_PORT_TYPE_CASCADED_SUBTAG

#define _BCM_KT2_SUBPORT_GROUP_MAX        (128)
#define _BCM_KT2_SUBPORT_PORT_MAX         (128)

#define _BCM_KT2_SUBPORT_PP_PORT_INDEX_MIN    (42) 
#define _BCM_KT2_SUBPORT_PP_PORT_INDEX_MAX    (\
    _BCM_KT2_SUBPORT_PP_PORT_INDEX_MIN + _BCM_KT2_SUBPORT_PORT_MAX - 1) 

#define _BCM_KT2_GPORT_IS_LINKPHY_OR_SUBTAG_SUBPORT_GPORT(_unit, _gport) \
    (BCM_GPORT_IS_SUBPORT_PORT(_gport) && \
        ((soc_feature(_unit, soc_feature_linkphy_coe) && \
        _BCM_KT2_GPORT_IS_LINKPHY_SUBPORT_PORT (_unit, _gport)) || \
        (soc_feature(_unit, soc_feature_subtag_coe) && \
         _BCM_KT2_GPORT_IS_SUBTAG_SUBPORT_PORT (_unit, _gport))))

#define _BCM_SB2_SUBPORT_PORT_MAX               (64)
#define _BCM_SB2_SUBPORT_GROUP_MAX              _BCM_SB2_SUBPORT_PORT_MAX

#define _BCM_SB2_SUBPORT_PP_PORT_INDEX_MIN      (30)
#define _BCM_SB2_SUBPORT_PP_PORT_INDEX_MAX      (\
        _BCM_SB2_SUBPORT_PP_PORT_INDEX_MIN + _BCM_SB2_SUBPORT_PORT_MAX -1)

/* LinkPHY subport specific defines */
#define _BCM_KT2_LINKPHY_STREAMS_MAX                1024
#define _BCM_KT2_LINKPHY_PER_PORT_STREAMS_MAX       128

#define _BCM_KT2_LINKPHY_TX_DATA_BUF_START_ADDR_MAX 3399
#define _BCM_KT2_LINKPHY_TX_DATA_BUF_END_ADDR_MIN   23
#define _BCM_KT2_LINKPHY_TX_DATA_BUF_END_ADDR_MAX   3423

#define _BCM_KT2_LINKPHY_STREAM_ID_FLUSH_TIMEOUT    20000

/*
* Katana2 LinkPHY/SubTag subport feature supports
* 1.creation of multiple logical subport groups per port.
*        Port/trunk_id and group id are stored in subport group gport.
* 2.attachment of multiple subport ports to a subport group
*       A subport port is represented by
*       a. (port, external stream id array)] for LinkPHY subport
*       b. (port, VLAN) for SubTag subport
*       Group id and subport_port id are stored in subport port gport.
*/

#define _BCM_KT2_SUBPORT_TYPE_ETHERNET   _BCM_SUBPORT_COE_TYPE_ETHERNET
#define _BCM_KT2_SUBPORT_TYPE_CASCADED   _BCM_SUBPORT_COE_TYPE_CASCADED
#define _BCM_KT2_SUBPORT_TYPE_LINKPHY    _BCM_SUBPORT_COE_TYPE_LINKPHY
#define _BCM_KT2_SUBPORT_TYPE_SUBTAG     _BCM_SUBPORT_COE_TYPE_SUBTAG

/*
* LinkPHY/SubTag Subport group gport format 
* bit 31-26 -- gport type (subport group)
* bit 25-24  -- subport group type (cascaded)
* bit 18-17 -- subport subtype (linkphy / subtag )
* bit 17    -- subport group is trunk indicator
* bit 16-9  -- subport group port number/trunk group id
* bit 8 -0  -- subport group index
*/
#define _BCM_KT2_SUBPORT_GROUP_TYPE_MASK \
            _BCM_SUBPORT_COE_GROUP_TYPE_MASK
#define _BCM_KT2_SUBPORT_GROUP_TYPE_SHIFT \
            _BCM_SUBPORT_COE_GROUP_TYPE_SHIFT
#define _BCM_KT2_SUBPORT_GROUP_SUBTYPE_MASK \
            _BCM_SUBPORT_COE_GROUP_SUBTYPE_MASK
#define _BCM_KT2_SUBPORT_GROUP_SUBTYPE_SHIFT \
            _BCM_SUBPORT_COE_GROUP_SUBTYPE_SHIFT
#define _BCM_KT2_SUBPORT_GROUP_PORT_MASK \
            _BCM_SUBPORT_COE_GROUP_PORT_MASK
#define _BCM_KT2_SUBPORT_GROUP_PORT_SHIFT \
            _BCM_SUBPORT_COE_GROUP_PORT_SHIFT
#define _BCM_KT2_SUBPORT_GROUP_SPGID_MASK \
            _BCM_SUBPORT_COE_GROUP_SPGID_MASK
#define _BCM_KT2_SUBPORT_GROUP_SPGID_SHIFT \
            _BCM_SUBPORT_COE_GROUP_SPGID_SHIFT
/*
* LinkPHY/SubTag Subport port gport format 
* bit 31-26  -- gport type (subport port)
* bit 25-24  -- subport port type (LinkPHY / SubTag)
* bit 23-08  -- zero
* bit 07-00  -- subport port index  (range 42 to 169)
*/

#define _BCM_KT2_SUBPORT_PORT_TYPE_MASK           0x3
#define _BCM_KT2_SUBPORT_PORT_TYPE_SHIFT          24
#define _BCM_KT2_SUBPORT_PORT_ZERO_BITS_MASK      0xFFFF
#define _BCM_KT2_SUBPORT_PORT_ZERO_BITS_SHIFT     8
#define _BCM_KT2_SUBPORT_PORT_PP_PORT_MASK        0xFF
#define _BCM_KT2_SUBPORT_PORT_PP_PORT_SHIFT       0

/* Check if gport is LinkPHY subport_group */
#define _BCM_KT2_GPORT_IS_LINKPHY_SUBPORT_GROUP(_subport_group)    \
            _BCM_COE_GPORT_IS_LINKPHY_SUBPORT_GROUP(_subport_group)

/* Check if gport is SubTag subport_group */
#define _BCM_KT2_GPORT_IS_SUBTAG_SUBPORT_GROUP(_subport_group)    \
            _BCM_COE_GPORT_IS_SUBTAG_SUBPORT_GROUP(_subport_group)

/* Set the subport port gport  type*/
#define _BCM_KT2_SUBPORT_PORT_TYPE_SET(_subport_port, _type)  \
             _BCM_SUBPORT_COE_PORT_TYPE_SET(_subport_port, _type)

/* Set the subport port gport  pp_port id*/
#define _BCM_KT2_SUBPORT_PORT_ID_SET(_subport_port, _pp_port)  \
    (BCM_GPORT_SUBPORT_PORT_SET((_subport_port), \
        ((_pp_port & _BCM_KT2_SUBPORT_PORT_PP_PORT_MASK) \
             << _BCM_KT2_SUBPORT_PORT_PP_PORT_SHIFT)))

/* Get the subport port gport pp_port id */
#define _BCM_KT2_SUBPORT_PORT_ID_GET(_subport_port)   \
    (((_subport_port) >> _BCM_KT2_SUBPORT_PORT_PP_PORT_SHIFT) & \
                         _BCM_KT2_SUBPORT_PORT_PP_PORT_MASK)


/* Check if gport is LinkPHY subport_port */
#define _BCM_KT2_GPORT_IS_LINKPHY_SUBPORT_PORT(_unit, _subport_port)    \
        (((((_subport_port) >> _BCM_KT2_SUBPORT_PORT_TYPE_SHIFT) & \
                        _BCM_KT2_SUBPORT_PORT_TYPE_MASK) == \
                        _BCM_KT2_SUBPORT_TYPE_LINKPHY) && \
         ((((_subport_port) >> _BCM_KT2_SUBPORT_PORT_ZERO_BITS_SHIFT) & \
                        _BCM_KT2_SUBPORT_PORT_ZERO_BITS_MASK) == 0) && \
        (BCM_PBMP_MEMBER(SOC_INFO(_unit).linkphy_pp_port_pbm, \
            (((_subport_port) >> _BCM_KT2_SUBPORT_PORT_PP_PORT_SHIFT) & \
                        _BCM_KT2_SUBPORT_PORT_PP_PORT_MASK))))

/* Check if gport is SubTag subport_port */
#define _BCM_KT2_GPORT_IS_SUBTAG_SUBPORT_PORT(_unit, _subport_port)    \
        (((((_subport_port) >> _BCM_KT2_SUBPORT_PORT_TYPE_SHIFT) & \
                        _BCM_KT2_SUBPORT_PORT_TYPE_MASK) == \
                        _BCM_KT2_SUBPORT_TYPE_SUBTAG) && \
         ((((_subport_port) >> _BCM_KT2_SUBPORT_PORT_ZERO_BITS_SHIFT) & \
                        _BCM_KT2_SUBPORT_PORT_ZERO_BITS_MASK) == 0) && \
        (BCM_PBMP_MEMBER(SOC_INFO(_unit).subtag_pp_port_pbm, \
            (((_subport_port) >> _BCM_KT2_SUBPORT_PORT_PP_PORT_SHIFT) & \
                        _BCM_KT2_SUBPORT_PORT_PP_PORT_MASK))))

typedef struct {
    bcm_port_t port;
    int        port_type;
    bcm_vlan_t subtag;
    int        num_streams;
    uint16     dev_int_stream_id[BCM_SUBPORT_CONFIG_MAX_STREAMS];
} _bcm_kt2_subport_info_t;

#define _BCM_SB2_SUBPORT_PORT_MAX               (64)
#define _BCM_SB2_SUBPORT_GROUP_MAX              _BCM_SB2_SUBPORT_PORT_MAX

#define _BCM_SB2_SUBPORT_PP_PORT_INDEX_MIN      (30)
#define _BCM_SB2_SUBPORT_PP_PORT_INDEX_MAX      (\
        _BCM_SB2_SUBPORT_PP_PORT_INDEX_MIN + _BCM_SB2_SUBPORT_PORT_MAX -1)

#endif /* BCM_KATANA2_SUPPORT */


#ifdef BCM_WARM_BOOT_SUPPORT
extern int _bcm_esw_subport_sync(int unit);
#endif /* BCM_WARM_BOOT_SUPPORT */

#ifdef BCM_WARM_BOOT_SUPPORT_SW_DUMP
extern void _bcm_tr_subport_sw_dump(int unit);
extern void _bcm_tr2_subport_sw_dump(int unit);
extern void _bcm_kt2_subport_sw_dump(int unit);

#endif /* BCM_WARM_BOOT_SUPPORT_SW_DUMP */

#endif /* !_BCM_INT_ESW_SUBPORT_H_ */
