/*
 * $Id: saber2.h,v 1.34 Broadcom SDK $ 
 * $Copyright: Copyright 2015 Broadcom Corporation.
 * This program is the proprietary software of Broadcom Corporation
 * and/or its licensors, and may only be used, duplicated, modified
 * or distributed pursuant to the terms and conditions of a separate,
 * written license agreement executed between you and Broadcom
 * (an "Authorized License").  Except as set forth in an Authorized
 * License, Broadcom grants no license (express or implied), right
 * to use, or waiver of any kind with respect to the Software, and
 * Broadcom expressly reserves all rights in and to the Software
 * and all intellectual property rights therein.  IF YOU HAVE
 * NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS SOFTWARE
 * IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE
 * ALL USE OF THE SOFTWARE.  
 *  
 * Except as expressly set forth in the Authorized License,
 *  
 * 1.     This program, including its structure, sequence and organization,
 * constitutes the valuable trade secrets of Broadcom, and you shall use
 * all reasonable efforts to protect the confidentiality thereof,
 * and to use this information only in connection with your use of
 * Broadcom integrated circuit products.
 *  
 * 2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS
 * PROVIDED "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES,
 * REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY,
 * OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
 * DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
 * NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES,
 * ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR
 * CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING
 * OUT OF USE OR PERFORMANCE OF THE SOFTWARE.
 * 
 * 3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL
 * BROADCOM OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL,
 * INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES WHATSOEVER
 * ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY
 * TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF
 * THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF OR USD 1.00,
 * WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING
 * ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.$
 *
 * File:        saber2.h
 * Purpose:     Function declarations for Saber2 bcm functions
 */

#ifndef _BCM_INT_SABER2_H_
#define _BCM_INT_SABER2_H_
#if defined(BCM_SABER2_SUPPORT)
#include <bcm_int/esw/subport.h>
#include <bcm_int/esw/firebolt.h>
#include <bcm_int/esw/mbcm.h>
#include <bcm_int/esw/oam.h>
#include <bcm_int/esw/field.h>
#include <bcm/qos.h>
#include <bcm/failover.h>
#include <bcm/sat.h>
#if defined(INCLUDE_L3)
extern int
bcm_sb2_failover_init(int unit);
extern int
bcm_sb2_failover_cleanup(int unit);
extern int bcm_sb2_failover_prot_nhi_cleanup(int unit,
                                                         int nh_index);
extern int bcm_sb2_failover_status_set(int unit,
                                            bcm_failover_element_t *failover,
                                            int value);
extern int bcm_sb2_failover_status_get(int unit,
                                            bcm_failover_element_t *failover,
                                            int  *value);
extern int
bcm_sb2_failover_prot_nhi_set(int unit, uint32 flags, int nh_index, uint32 prot_nh_index, 
                                           bcm_multicast_t  mc_group, bcm_failover_t failover_id);

#endif
/* OAM ING/EGR_SERVICE_PRI_MAP_0/1/2 memory related routines */
#define _BCM_SB2_OAM_PRI_MAP_COUNTER_OFFSET_MAX 7
#define _BCM_SB2_OAM_PRI_MAP_COUNTER_OFFSET_MIN 0

#define _BCM_SB2_INT_PRI_MAX                15
#define _BCM_SB2_INT_PRI_MIN                0

#define _BCM_SB2_PKT_PRI_MAX                7
#define _BCM_SB2_PKT_PRI_MIN                0

#define _BCM_SB2_MPLS_EXP_MAX               7
#define _BCM_SB2_MPLS_EXP_MIN               0

#define _BCM_SB2_OAM_PRI_MAP_TABLE_MAX      6

extern int _bcm_sb2_port_lanes_set_post_operation(int unit, bcm_port_t port);
extern int _bcm_sb2_port_lanes_set(int unit, bcm_port_t port, int value);
extern int _bcm_sb2_port_lanes_get(int unit, bcm_port_t port, int *value);
extern int bcm_sb2_flexio_pbmp_update(int unit, bcm_pbmp_t *pbmp);

extern int bcm_sb2_oam_init(int unit);

extern int bcm_sb2_oam_detach(int unit);

extern int bcm_sb2_oam_group_create(int unit, bcm_oam_group_info_t *group_info);

extern int bcm_sb2_oam_group_get(int unit, bcm_oam_group_t group,
                                 bcm_oam_group_info_t *group_info);

extern int bcm_sb2_oam_group_destroy(int unit, bcm_oam_group_t group);

extern int bcm_sb2_oam_group_destroy_all(int unit);

extern int bcm_sb2_oam_group_traverse(int unit, bcm_oam_group_traverse_cb cb,
                                      void *user_data);

extern int bcm_sb2_oam_endpoint_create(int unit,
                                       bcm_oam_endpoint_info_t *endpoint_info);

extern int bcm_sb2_oam_endpoint_get(int unit, bcm_oam_endpoint_t endpoint,
                                    bcm_oam_endpoint_info_t *endpoint_info);

extern int bcm_sb2_oam_endpoint_destroy(int unit, bcm_oam_endpoint_t endpoint);

extern int bcm_sb2_oam_endpoint_destroy_all(int unit, bcm_oam_group_t group);

extern int bcm_sb2_oam_endpoint_traverse(int unit, bcm_oam_group_t group,
                                         bcm_oam_endpoint_traverse_cb cb,
                                         void *user_data);

extern int bcm_sb2_oam_event_register(int unit, 
                                      bcm_oam_event_types_t event_types,
                                      bcm_oam_event_cb cb, void *user_data);

extern int bcm_sb2_oam_event_unregister(int unit, 
                                      bcm_oam_event_types_t event_types,
                                      bcm_oam_event_cb cb);

extern int bcm_sb2_oam_endpoint_action_set(int unit, bcm_oam_endpoint_t id, 
                                           bcm_oam_endpoint_action_t *action); 

extern int _bcm_sb2_port_control_oam_loopkup_with_dvp_set(int unit, 
                                                          bcm_port_t port, 
                                                          int val);
extern int _bcm_sb2_port_control_oam_loopkup_with_dvp_get(int unit, 
                                                          bcm_port_t port, 
                                                          int *val);
extern int bcm_sb2_oam_lookup_enable_set( int unit, bcm_oam_lookup_type_t type,
        bcm_oam_condition_t condition, int enable);
extern int bcm_sb2_oam_lookup_enable_multi_set(int unit, bcm_oam_lookup_types_t type,
        bcm_oam_conditions_t condition, int enable);
extern int bcm_sb2_oam_lookup_enable_get(int unit, bcm_oam_lookup_type_t type,
        bcm_oam_conditions_t *condition);
#ifdef BCM_WARM_BOOT_SUPPORT_SW_DUMP /* BCM_WARM_BOOT_SUPPORT_SW_DUMP*/
extern void _bcm_sb2_oam_sw_dump(int unit);
#endif /* !BCM_WARM_BOOT_SUPPORT_SW_DUMP */
#ifdef BCM_WARM_BOOT_SUPPORT /* BCM_WARM_BOOT_SUPPORT */
extern int _bcm_sb2_oam_sync(int unit);
extern int _bcm_sb2_ipmc_repl_reload(int unit);
#endif/* BCM_WARM_BOOT_SUPPORT */
extern int bcm_sb2_oam_loopback_add(int unit, bcm_oam_loopback_t *loopback_p);
extern int bcm_sb2_oam_loopback_get(int unit, bcm_oam_loopback_t *loopback_p);
extern int bcm_sb2_oam_loopback_delete(int unit, bcm_oam_loopback_t *loopback_p);
extern int bcm_sb2_oam_loss_add( int unit, bcm_oam_loss_t *loss_ptr);
extern int bcm_sb2_oam_loss_delete( int unit, bcm_oam_loss_t *loss_ptr);
extern int bcm_sb2_oam_loss_get( int unit, bcm_oam_loss_t *loss_ptr);
extern int bcm_sb2_oam_delay_add( int unit, bcm_oam_delay_t *delay_ptr);
extern int bcm_sb2_oam_delay_delete( int unit, bcm_oam_delay_t *delay_ptr);
extern int bcm_sb2_oam_delay_get( int unit, bcm_oam_delay_t *delay_ptr);
extern int bcm_sb2_stg_stp_init(int unit, bcm_stg_t stg);
extern int bcm_sb2_stg_stp_set(int unit, bcm_stg_t stg, 
                         bcm_port_t port, int stp_state);
extern int bcm_sb2_stg_stp_get(int unit, bcm_stg_t stg, 
                         bcm_port_t port, int *stp_state);
extern int bcm_sb2_oam_control_get(int unit, 
                                   bcm_oam_control_type_t type,
                                   uint64  *arg); 
extern int bcm_sb2_oam_control_set(int unit, 
                                   bcm_oam_control_type_t type,
                                   uint64 arg); 

extern int
bcm_sb2_oam_pm_profile_create(int unit, bcm_oam_pm_profile_info_t *profile_info);
extern int
bcm_sb2_oam_pm_profile_delete(int unit, bcm_oam_pm_profile_t profile_id);
extern int
bcm_sb2_oam_pm_profile_delete_all(int unit);
extern int 
bcm_sb2_oam_pm_profile_detach(int unit, bcm_oam_endpoint_t endpoint_id,
                                  bcm_oam_pm_profile_t profile_id);
extern int
bcm_sb2_oam_pm_profile_get(int unit, bcm_oam_pm_profile_info_t *profile_info);
extern int
bcm_sb2_oam_pm_profile_traverse(int unit,
                    bcm_oam_pm_profile_traverse_cb cb, void *user_data);
extern int bcm_sb2_oam_pm_stats_get(int unit,
                            bcm_oam_endpoint_t endpoint_id, bcm_oam_pm_stats_t *stats_ptr);
extern int bcm_sb2_oam_pm_event_register(int unit, bcm_oam_event_types_t event_types,
                                    bcm_oam_pm_event_cb cb, void *user_data);
extern int bcm_sb2_oam_pm_event_unregister(int unit, bcm_oam_event_types_t event_types,
                                     bcm_oam_pm_event_cb cb);
extern int
bcm_sb2_oam_pm_raw_data_read_done(int unit, bcm_oam_event_types_t event_types,
                                  uint32 read_index);
extern int
bcm_sb2_oam_pm_profile_attach_get(
        int unit, bcm_oam_endpoint_t endpoint_id, bcm_oam_pm_profile_t *profile_id);
extern int
bcm_sb2_oam_pm_profile_attach(int unit, bcm_oam_endpoint_t endpoint_id,
        bcm_oam_pm_profile_t profile_id);



extern int bcm_sb2_sat_init(int unit);
extern int bcm_sb2_sat_detach(int unit);
extern int bcm_sb2_sat_endpoint_create(int unit,
                                       bcm_sat_endpoint_info_t *endpoint_info);

extern int bcm_sb2_sat_endpoint_get(int unit, 
                                    bcm_sat_endpoint_t endpoint,
                                    uint32 flags,
                                    bcm_sat_endpoint_info_t *endpoint_info);

extern int bcm_sb2_sat_endpoint_destroy(int unit, 
                                        bcm_sat_endpoint_t endpoint,
                                        uint32 flags);

extern int bcm_sb2_sat_endpoint_destroy_all(int unit, uint32  flags);

extern int bcm_sb2_sat_endpoint_traverse(int unit, uint32 flags,
                                         bcm_sat_endpoint_traverse_cb cb,
                                         void *user_data);

extern int bcm_sb2_sat_oamp_enable(int unit, int enable); 
extern int bcm_sb2_sat_ts_format_set(int unit, int ts_format); 

extern int _bcm_sb2_port_sw_info_display(int unit, bcm_port_t port);
extern int _bcm_sb2_port_hw_info_display(int unit, bcm_port_t port);

extern  int
 _bcm_sb2_ipmc_subscriber_egress_intf_add(int unit, int ipmc_id,
                                         bcm_port_t port,
                                         int id,
                                         bcm_gport_t subscriber_queue,
                                         int is_l3,
                                         int *queue_count,
                                         int *q_count_increased
                                         );
 extern int
 _bcm_sb2_ipmc_subscriber_egress_intf_delete(int unit, int ipmc_id,
                                             bcm_port_t port,
                                             int id,
                                             bcm_gport_t subscriber_queue,
                                             int *queue_count,
                                             int *q_count_increased
                                          );
extern  int
_bcm_sb2_ipmc_subscriber_egress_intf_set(int unit, int ipmc_id,
                                         bcm_port_t port, int if_count,
                                         int *id,
                                         bcm_gport_t subscriber_queue,
                                         int is_l3,
                                         int *queue_count,
                                         int *q_count_increased);
int
 _bcm_sb2_ipmc_subscriber_egress_intf_get(int unit, int ipmc_id, int if_max,
                                          bcm_gport_t *port_array,
                                         bcm_if_t *if_array,
                                         bcm_gport_t *subs_array,
                                         int *count);

extern  void 
_bcm_sb2_ipmc_port_ext_queue_count_increment(int unit,
                                       int ipmc_id, bcm_port_t port);

extern  void _bcm_sb2_ipmc_port_ext_queue_count_decrement(int unit,
                                       int ipmc_id, bcm_port_t port);

extern  int
 _bcm_sb2_ipmc_set_remap_group(int unit, int ipmc_id,
                             bcm_port_t port, int count);


#ifdef BCM_WARM_BOOT_SUPPORT
extern int
bcm_sb2_failover_sync(int unit);
#endif

#endif /* BCM_SABER2_SUPPORT */
#endif  /* !_BCM_INT_SABER2_H_ */

